# CSCI218 Project H — Tanisha's contribution (corrected package)

## November 18 integration update

The Flat A* module now also supports optional `allowed` nodes and `trace=True` for a shared demo interface. **The actual baseline must always use `allowed=None`** so it searches the complete road graph. `expanded_trace` is only collected on request; `nodes_expanded` keeps the original search metric. The packaged Humna `References` files are updated to her November 18 fixes; `faaiz_two_tier_search.py` is included there for compatibility testing only, and is **not Tanisha's work**.

All **18 tests passed** (12 small-graph, four baseline real-map, and two shared-graph integration tests). On Humna's current 23,400-node Jumeirah graph, the flat route is 6,551.713 m. Faaiz's corrected two-tier method returned a valid 7,454.391 m route on the same normal graph in one integration check. A separate targeted closure case can make the destination unreachable; both algorithms agree with Dijkstra in that situation. This is **not** a benchmark: timing boundaries require agreement before comparing performance. Re-run Mia's full experiments with the final merged code.

## Scope and attribution
This package contains **Tanisha's flat A* baseline and validation tests**, plus report drafts for **Section C (Technical Requirements)** and **Section G (Limitations)**. `References/osm_map.py` and `References/first_level_search.py` are **Humna's source files**. `References/faaiz_two_tier_search.py` is **Faaiz's algorithm with integration corrections**. All three references are included solely to reproduce the shared-graph tests; they are not Tanisha's authored contribution. Mia's experiments and Harshal's demonstration are not included.

The work and report are AI-assisted; the student must review, understand, acknowledge and verify compliance with the subject's assessment-specific GenAI rules. Track and attribute any changes accurately in the group Git repository.

## Folder contents
- `Code/flat_astar.py` — full-road-network A*, heuristic, path validation, result fields.
- `Code/test_flat_astar.py` — 12 synthetic-map unit tests.
- `Code/test_integration.py` — two same-graph tests against Faaiz's corrected algorithm.
- `Code/test_real_map.py` — 4 full-dataset tests: normal cost, blocked cost and original route/closure non-overlap.
- `Code/run_flat_astar.py` — simple command-line demonstration.
- `Code/validate_real_map.py` — full repeatable normal/blocked case study with Dijkstra and explanatory JSON.
- `Data/jumeirah.osm` — supplied OSM map dataset.
- `References/osm_map.py`, `References/first_level_search.py` — Humna's supporting implementation, **not Tanisha's**.
- `Report/Tanisha_Sections_C_and_G_UPDATED.docx` — updated report content.
- `Results/real_map_results.json` — verified metrics; timing is a single run.
- `Results/HANDOVER_FOR_MIA_AND_HARSHAL.md` — interface, metrics, caveats and contribution evidence.

## Setup
Requires Python **3.10+**; all included Python scripts use the standard library. Open a terminal in the extracted `Tanisha_Final` folder. No separate OSM download is necessary because `Data/jumeirah.osm` is included.

## Execute tests
```bash
python -m unittest discover -s Code -v
```
Expected: **18 passing tests** (12 synthetic + 4 real-map + 2 shared integration).

## Reproduce the case study and JSON
```bash
python Code/validate_real_map.py
```
This regenerates `Results/real_map_results.json` using the actual supplied graph and a **60 m** roadblock around the middle node of the middle leg of Humna's original first-level route, matching her `run_demo.py` logic.

To run the baseline directly:
```bash
python Code/run_flat_astar.py
python Code/run_flat_astar.py --roadblock
```

## Verified result (supplied map; Boxpark → Port de La Mer)
| Metric | No block | With block |
|---|---:|---:|
| Flat A* shortest distance (m) | 6,551.713 | 6,551.713 |
| Dijkstra shortest distance (m) | 6,551.713 | 6,551.713 |
| Nodes expanded | 9,363 | 9,339 |
| Directed edges closed | 0 | 25 |
| Humna's first-level path (m) | 7,212.520 | 7,238.621 |

**Why no change?** Zero closed edges intersect the original Flat A* path. The route is unchanged, but expansion work can differ because closures change which alternatives are explored. This behavior is independently asserted by a real-map test.

*Note:* Humna's supplied screenshot shows 7,346 m in a previous roadblock visualization; the source files supplied here reproduce **7,238.621 m** using the current default 60-m closure rule. Confirm whether the screenshot was made with another radius, file revision, or scenario before including it in joint results.

## Caveats / further group work
1. Faaiz's original notebook used a different graph representation. The *corrected* algorithm in `References/` now accepts the same `RoadMap`, but the group must still standardize metrics and compare complete final versions across multiple scenarios.
2. Above first-level numbers are Humna's **macro search**, not the integrated final two-tier second-level search.
3. Search timings are local single runs, not statistical evidence; Mia should benchmark repeated runs under consistent settings, including or separately reporting preprocessing for both methods.
4. Harshal must integrate the demonstration, merge repository work and record actual contribution evidence. Tanisha must review Faaiz's assigned sections and prepare a truthful individual reflection separately.
