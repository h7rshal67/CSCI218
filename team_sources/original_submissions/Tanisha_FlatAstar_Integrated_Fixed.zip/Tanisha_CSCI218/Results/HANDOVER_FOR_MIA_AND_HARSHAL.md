# Handover: Tanisha's Flat A* baseline

## Function interface
`from flat_astar import flat_astar, route_cost`

`flat_astar(road_map, start_node, goal_node, blocked=())` returns `SearchResult(found, path, cost_m, nodes_expanded, runtime_ms)`. Node IDs are those from **Humna's `RoadMap.adj`**; `blocked` is a set of directed `(u,v)` pairs.

## Case-study results (one execution, not benchmark averages)
- Boxpark → Port de La Mer normal: 6,551.713 m, 9,363 nodes expanded.
- Same with Humna's 60-m blockage: 6,551.713 m, 9,339 expanded, 25 closed directed road edges.
- Dijkstra confirms both shortest costs; `route_cost` confirms open paths.
- None of the 25 closures overlaps the original flat route, so the path is unchanged.
- For an auditable reproduction, see `Code/validate_real_map.py` and the JSON file.

## Integration conditions for Mia
- Use exactly the same map, named start/goal **road node IDs**, directed blocked-edge set and edge lengths.
- Give both algorithms consistent route validity and node-expansion definitions.
- Measure repeated query runtimes separately from graph construction/preprocessing and report variability.
- Do **not** directly compare Humna's first-level macro length or Faaiz's old OSMnx notebook numbers to this graph without integration.

## Evidence for Harshal's Implementation section
- File: `Code/flat_astar.py`; priority queue `f=g+h`, haversine heuristic and predecessor reconstruction.
- File: `Code/test_flat_astar.py`; start=goal, one-way, no route, detour and Dijkstra checks.
- File: `Code/test_real_map.py`; same-map Dijkstra and closed edge verification.
- Command: `python -m unittest discover -s Code -v` (14 passing tests).
- Command: `python Code/validate_real_map.py` (regenerates JSON).
- Include a genuine terminal screenshot captured by your group when run on your machine, not a fabricated screenshot.

## Contribution table row (edit to reflect actual work and verified Git commits)
| Member | Contribution | Evidence |
|---|---|---|
| Tanisha | Flat A* baseline and tests; technical requirements and limitations draft; real-map verification | `Code/flat_astar.py`, `Code/test_*.py`, `Code/validate_real_map.py`, Sections C & G; add actual commit links after review |

AI-assisted drafting/coding must be disclosed according to the assessment rules. Do not claim personal authorship of code produced by another team member or of steps not personally validated.
