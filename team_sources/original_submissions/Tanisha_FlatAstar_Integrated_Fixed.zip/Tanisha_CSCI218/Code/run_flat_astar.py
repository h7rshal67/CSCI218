"""Quick Flat A* demonstration on the packaged Jumeirah dataset.
Usage: python Code/run_flat_astar.py [--roadblock] [--radius 60]
"""
import argparse, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'References'))
from osm_map import RoadMap, dijkstra_path
from first_level_search import build_hub_map, first_level_search
from flat_astar import flat_astar, route_cost

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--roadblock',action='store_true')
    p.add_argument('--radius',type=float,default=60.0)
    p.add_argument('--start',default='Boxpark')
    p.add_argument('--goal',default='Port de La Mer')
    a=p.parse_args()
    rm=RoadMap(str(ROOT/'Data'/'jumeirah.osm'))
    blocked=set()
    if a.roadblock:
        macro=first_level_search(rm,build_hub_map(rm),a.start,a.goal)
        if not macro['found'] or not macro['legs']: raise RuntimeError('No hub route to derive roadblock')
        leg=macro['legs'][len(macro['legs'])//2]
        blocked=rm.edges_near(*rm.coords[leg[len(leg)//2]],a.radius)
    r=flat_astar(rm,rm.hub_node[a.start],rm.hub_node[a.goal],blocked)
    print('Road nodes:',len(rm.adj),'closed directed edges:',len(blocked))
    print('Flat A*:',r.as_dict())
    if r.found:
        d,_=dijkstra_path(rm.adj,rm.hub_node[a.start],rm.hub_node[a.goal],blocked=blocked)
        print('Dijkstra:',d,'independent path cost:',route_cost(rm,r.path,blocked))

if __name__=='__main__': main()
