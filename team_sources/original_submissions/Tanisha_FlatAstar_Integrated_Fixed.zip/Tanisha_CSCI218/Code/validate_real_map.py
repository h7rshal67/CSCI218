"""Reproducible single-run and blocked-route validation, using Humna's map.

Run from anywhere: python Code/validate_real_map.py
Output: Results/real_map_results.json
"""
from pathlib import Path
import json, sys, math
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'References'))
sys.path.insert(0, str(ROOT / 'Code'))
from osm_map import RoadMap, dijkstra_path
from first_level_search import build_hub_map, first_level_search
from flat_astar import flat_astar, route_cost


def main():
    rm = RoadMap(str(ROOT / 'Data' / 'jumeirah.osm'))
    start_name, goal_name = 'Boxpark', 'Port de La Mer'
    s, t = rm.hub_node[start_name], rm.hub_node[goal_name]
    macro = first_level_search(rm, build_hub_map(rm), start_name, goal_name)
    if not macro['found'] or not macro['legs']:
        raise RuntimeError('First-level path unavailable; cannot reproduce Humna roadblock')
    middle_leg = macro['legs'][len(macro['legs']) // 2]
    point = middle_leg[len(middle_leg) // 2]
    closed = rm.edges_near(*rm.coords[point], 60)
    flat0 = flat_astar(rm, s, t)
    flat1 = flat_astar(rm, s, t, closed)
    macro1 = first_level_search(rm, build_hub_map(rm, closed), start_name, goal_name)
    dij0, _ = dijkstra_path(rm.adj, s, t)
    dij1, _ = dijkstra_path(rm.adj, s, t, blocked=closed)
    if not (flat0.found and flat1.found and macro1['found']):
        raise AssertionError('Expected route was not found')
    for res, cost, blocks in [(flat0, dij0, set()), (flat1, dij1, closed)]:
        assert math.isclose(res.cost_m, cost, abs_tol=1e-5)
        assert math.isclose(route_cost(rm, res.path, blocks), cost, abs_tol=1e-5)
    edges0 = set(zip(flat0.path, flat0.path[1:]))
    edges1 = set(zip(flat1.path, flat1.path[1:]))
    intersections = len(edges0 & closed)
    records = {
        'dataset': 'Supplied jumeirah (1).osm; Humna osm_map.py',
        'start': start_name, 'goal': goal_name,
        'road_nodes': len(rm.adj), 'hubs': len(rm.hub_node),
        'roadblock_rule': '60m around middle node of middle hub-route leg (Humna run_demo.py)',
        'blocked_directed_edges': len(closed),
        'baseline_shortest_route_edges_blocked': intersections,
        'baseline_path_unchanged_by_closure': flat0.path == flat1.path,
        'normal': {**flat0.as_dict(), 'dijkstra_m': dij0,
                   'first_level_cost_m': macro['cost_m']},
        'roadblock': {**flat1.as_dict(), 'dijkstra_m': dij1,
                      'first_level_cost_m': macro1['cost_m']},
        'note': 'Single-run timings are descriptive, not averages. Hub search costs are not the fully integrated second-level method.'
    }
    output = ROOT / 'Results' / 'real_map_results.json'
    output.write_text(json.dumps(records, indent=2), encoding='utf-8')
    print(json.dumps({k:v for k,v in records.items() if k not in ('normal','roadblock')},indent=2))
    for name in ('normal','roadblock'):
        r=records[name]
        print(name, 'flat_m',round(r['cost_m'],3),'expanded',r['nodes_expanded'], 'ms',round(r['runtime_ms'],3),'hub_m',round(r['first_level_cost_m'],3))
    print('Saved',output)

if __name__ == '__main__':
    main()
