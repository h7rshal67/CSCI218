"""Check Tanisha's baseline against the same graph used by Faaiz and Humna."""
import math
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'References'))
from osm_map import RoadMap, dijkstra_path
from faaiz_two_tier_search import two_tier_search
from flat_astar import flat_astar, route_cost


class SharedGraphTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.graph = RoadMap(str(ROOT / 'Data' / 'jumeirah.osm'))
        cls.start = cls.graph.hub_node['Boxpark']
        cls.goal = cls.graph.hub_node['Port de La Mer']

    def test_both_methods_same_graph_and_valid_paths(self):
        a = flat_astar(self.graph, self.start, self.goal)
        t = two_tier_search(self.graph, self.start, self.goal)
        self.assertTrue(a.found and t['found'])
        self.assertEqual(t['path'][0], self.start)
        self.assertEqual(t['path'][-1], self.goal)
        self.assertTrue(math.isclose(t['cost_m'], route_cost(self.graph, t['path']), abs_tol=1e-5))
        self.assertGreaterEqual(t['cost_m'] + 1e-5, a.cost_m)
        dij, _ = dijkstra_path(self.graph.adj, self.start, self.goal)
        self.assertTrue(math.isclose(dij, a.cost_m, abs_tol=1e-5))

    def test_directed_roadblock_shared_by_both(self):
        base = flat_astar(self.graph, self.start, self.goal)
        middle = base.path[len(base.path) // 2]
        closed = self.graph.edges_near(*self.graph.coords[middle], 60)
        a = flat_astar(self.graph, self.start, self.goal, closed)
        t = two_tier_search(self.graph, self.start, self.goal, closed)
        dij, _ = dijkstra_path(self.graph.adj, self.start, self.goal, blocked=closed)
        self.assertEqual(a.found, dij is not None)
        self.assertEqual(t['found'], dij is not None)  # fallback preserves reachability
        if dij is not None:
            self.assertTrue(math.isclose(route_cost(self.graph, a.path, closed), a.cost_m, abs_tol=1e-5))
            self.assertTrue(math.isclose(route_cost(self.graph, t['path'], closed), t['cost_m'], abs_tol=1e-5))
            self.assertGreaterEqual(t['cost_m'] + 1e-5, a.cost_m)


if __name__ == '__main__':
    unittest.main()
