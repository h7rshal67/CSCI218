# Repair and verification notes (19 November 2026)

## What was fixed

- The supplied `two_tier_search.py` contained Word-document binary data rather than Python code and caused a `SyntaxError`. It has been reconstructed as a working Python module exposing `prepare_hierarchy()` and `two_tier_search()` with the interfaces used by the demo, tests, and experiments.
- The hierarchy uses connected regions within 8-by-8 tiles, an abstract region-level search, a restricted detailed A* search, progressive widening, and a full-network fallback where necessary.
- The 600 measured searches were rerun, the summary CSV and figure were regenerated, and the numbers and embedded figure in the Part A/F report were refreshed from those results.
- Benchmark metadata no longer claims an unverified Git commit; the actual commit SHA should be recorded after the team merges these changes.

## Verification

From this folder, run:

```bash
python -m unittest discover -s tests -q
python -m experiments.integrated_benchmark
python -m experiments.plot_benchmark
python demo.py --no-browser
```

The verification run passed 24 tests. The benchmark used 3 grid sizes, 10 seeds, and 10 repetitions per algorithm, for **600 measured searches**. All generated routes were checked for validity, and flat A* path costs were cross-checked against breadth-first search.

## Interpretation and integration

- The benchmark's measured **query time excludes grid generation and hierarchy preprocessing**; those costs are reported separately. Absolute times vary by computer and rerun.
- Two-tier A* reduces search effort and query time in these grids, but its restricted corridor can yield longer paths than flat A*. Do not describe it as globally optimal.
- The recreated two-tier module should be reviewed by the teammate responsible for that algorithm before the final group merge. This ZIP is a corrected integrated working copy, not proof that a particular teammate authored every repaired line.
- Individual contributors should commit only work they actually performed to the team Git repository, and the final report's contribution table should reflect that history accurately.
