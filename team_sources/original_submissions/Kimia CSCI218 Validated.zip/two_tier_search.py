"""Two-tier A* using the same offline World as the flat A* baseline.

This module restores the Python interface expected by Mia's integrated demo
and benchmarks. It uses Faaiz's region-corridor, widening and fallback design.
"""
from __future__ import annotations

import heapq
import math
import time
from dataclasses import dataclass, field

from flat_astar import flat_astar


@dataclass
class Hierarchy:
    members: dict
    centers: dict
    adj: dict
    blocked: frozenset
    preprocess_ms: float


@dataclass
class TwoTierResult:
    found: bool
    path: list
    cost_m: float | None
    nodes_expanded: int
    runtime_ms: float
    trace: list = field(default_factory=list)
    abstract_expanded: int = 0
    region_path: list = field(default_factory=list)
    mode: str = ''
    attempts: int = 0


def prepare_hierarchy(world, blocked=()):
    """Build directed abstract links from open road/grid edges once per map."""
    t0 = time.perf_counter()
    closed = frozenset(blocked)
    members = {}
    for n in world.adj:
        members.setdefault(world.area[n], set()).add(n)
    centers = {}
    for region, nodes in members.items():
        coords = [world.coords[n] for n in nodes]
        centers[region] = tuple(sum(p[i] for p in coords) / len(coords)
                                for i in (0, 1))
    adj = {r: {} for r in members}
    for u, neighbors in world.adj.items():
        for v in neighbors:
            if (u, v) in closed:
                continue
            ra, rb = world.area[u], world.area[v]
            if ra != rb:
                # Distances between abstract centers are estimates for
                # corridor selection, never the returned detailed road cost.
                adj[ra][rb] = world.distance(centers[ra], centers[rb])
    return Hierarchy(members, centers, adj, closed,
                     (time.perf_counter() - t0) * 1000)


def _region_astar(world, hierarchy, source, target):
    if source == target:
        return [source], 0
    centers, adj = hierarchy.centers, hierarchy.adj
    h = lambda r: world.distance(centers[r], centers[target])
    sequence = 0
    heap = [(h(source), 0., sequence, source)]
    best, came = {source: 0.}, {}
    expanded = 0
    while heap:
        _, cost, _, current = heapq.heappop(heap)
        if cost > best[current] + 1e-9:
            continue
        expanded += 1
        if current == target:
            route = [current]
            while route[-1] in came:
                route.append(came[route[-1]])
            return list(reversed(route)), expanded
        for nb, weight in adj[current].items():
            candidate = cost + weight
            if candidate + 1e-9 < best.get(nb, math.inf):
                best[nb], came[nb] = candidate, current
                sequence += 1
                heapq.heappush(heap, (candidate + h(nb), candidate, sequence, nb))
    return [], expanded


def two_tier_search(world, start, goal, blocked=(), *, hierarchy=None,
                    collect_trace=False):
    """Find a route in chosen areas, widen on failure, then fall back to full map.

    `nodes_expanded` counts all detailed expansions including failed attempts.
    `abstract_expanded` is reported separately. Preprocessing is excluded from
    query runtime when a prebuilt hierarchy is supplied by the benchmark.
    """
    t0 = time.perf_counter()
    closed = frozenset(blocked)
    if start not in world.adj or goal not in world.adj:
        raise ValueError('Unknown start or goal node')
    if hierarchy is not None and hierarchy.blocked != closed:
        raise ValueError('Hierarchy was prepared with a different closure set')
    if start == goal:
        return TwoTierResult(True, [start], 0., 0,
                             (time.perf_counter() - t0) * 1000, mode='Same node')
    if hierarchy is None:
        hierarchy = prepare_hierarchy(world, closed)
    regions, abstract_expanded = _region_astar(
        world, hierarchy, world.area[start], world.area[goal])
    search_attempts = []
    if regions:
        chosen = set(regions)
        search_attempts.append(('Chosen regions', chosen))
        wider = set(chosen)
        for region in chosen:
            wider.update(hierarchy.adj[region])
        for region, links in hierarchy.adj.items():
            if chosen.intersection(links):
                wider.add(region)
        if wider != chosen:
            search_attempts.append(('Widened to neighbouring regions', wider))
    search_attempts.append(('Whole-map fallback', None))

    total, trace = 0, []
    for attempt_num, (mode, region_set) in enumerate(search_attempts, 1):
        allowed = (None if region_set is None else
                   set().union(*(hierarchy.members[r] for r in region_set)))
        r = flat_astar(world, start, goal, closed,
                       heuristic=world.heuristic(goal), allowed_nodes=allowed,
                       collect_trace=collect_trace)
        total += r.nodes_expanded
        if collect_trace:
            trace.extend(r.trace)
        if r.found or region_set is None:
            return TwoTierResult(r.found, r.path, r.cost_m, total,
                                 (time.perf_counter() - t0) * 1000,
                                 trace, abstract_expanded, regions, mode,
                                 attempt_num)
    raise AssertionError('Unreachable fallback state')
