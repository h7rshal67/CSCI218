# Faaiz two-tier search — integration corrections

This folder contains the corrected `faaiz_two_tier_search.py` using Humna's `RoadMap` (`adj`, `coords`, and `area`). The `osm_map.py` copy is **Humna's supporting code**, not Faaiz's contribution.

## Changes

- Directed roadblocks remain directional; no automatic reverse edge is closed.
- Road-node expansions from **all** detailed A* attempts are exposed as `nodes_expanded` (comparable to Tanisha's flat A*).
- Abstract region expansions are separately available as `region_nodes_expanded` and combined count as `total_nodes_expanded`.
- `attempt_expansions` records each corridor, widening, and fallback attempt.
- `preprocessing_ms` reports region-graph construction; `runtime_ms` reports the entire search including preprocessing. Avoid comparing this directly with Flat A*'s search-only timing without accounting for preprocessing.
- More robust outdated queue handling, invalid-node/weight checks, allowed start/goal validation, and final route/closure checks.

## Verification

Six new synthetic tests passed using:

```bash
PYTHONPATH=. python -m unittest discover -s tests -p test_faaiz_synthetic.py -v
```

The supplied original `tests/test_faaiz_two_tier_search.py` expects a real map at `data/jumeirah.osm`; it **has not been rerun** because this data file was not included in the current upload. To run the original tests, put the group's agreed `jumeirah.osm` under `data/`, then use `PYTHONPATH=. python -m unittest discover -s tests -v`.

## Integration

The group should use the same OSM dataset, map parser, directed closed edges, origin and destination nodes, and route-cost units for Tanisha's Flat A* and Faaiz's two-tier A*. Ask Mia to report **detailed expansions**, **region expansions**, and **preprocessing time** distinctly. Faaiz should review and run the changes himself, then commit them under his own GitHub account with accurate acknowledgement of AI assistance.
