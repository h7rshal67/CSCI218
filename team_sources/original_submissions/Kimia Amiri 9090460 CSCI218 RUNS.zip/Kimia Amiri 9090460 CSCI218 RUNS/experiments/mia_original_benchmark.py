"""Deterministic grid generator used by the shared world module."""

import random
from collections import deque


def grid(size, seed):
    rng = random.Random(seed)
    cells = {(r, c) for r in range(1, size - 1)
             for c in range(1, size - 1) if rng.random() >= .25}
    graph = {}
    for r, c in sorted(cells):
        graph[r, c] = tuple(p for p in ((r-1,c), (r+1,c), (r,c-1), (r,c+1)) if p in cells)
    start = min(graph, key=lambda p: (sum(p), p))
    distances = {start: 0}
    frontier = deque([start])
    while frontier:
        node = frontier.popleft()
        for nxt in graph[node]:
            if nxt not in distances:
                distances[nxt] = distances[node] + 1
                frontier.append(nxt)
    goal = max(distances, key=lambda p: (sum(p), p))
    return graph, start, goal, distances[goal]
