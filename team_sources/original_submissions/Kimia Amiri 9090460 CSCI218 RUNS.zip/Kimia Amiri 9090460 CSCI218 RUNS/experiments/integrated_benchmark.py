"""Reproducible scaling experiments on the SAME algorithms used by the demo."""
from __future__ import annotations

import csv
import json
import platform
import statistics
import sys
from collections import deque
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter_ns

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from flat_astar import flat_astar, route_cost
from two_tier_search import prepare_hierarchy, two_tier_search
from worlds import grid_world


def write_csv(path, rows):
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def bfs_distances(adj, start, blocked, allowed=None):
    distances = {start: 0}
    queue = deque([start])
    while queue:
        node = queue.popleft()
        for neighbor in adj[node]:
            if neighbor in distances or (node, neighbor) in blocked:
                continue
            if allowed is None or neighbor in allowed:
                distances[neighbor] = distances[node] + 1
                queue.append(neighbor)
    return distances


def check_areas(world, blocked):
    assert world.area.keys() == world.adj.keys(), "Area coverage differs from open cells"
    areas = {}
    for node, label in world.area.items():
        areas.setdefault(label, set()).add(node)
    for members in areas.values():
        start = next(iter(members))
        assert all(world.base_areas[n] == world.base_areas[start] for n in members)
        assert bfs_distances(world.adj, start, blocked, members).keys() == members


def run_benchmark(output=None, *, sizes=(32, 64, 128), seeds=10, repeats=10):
    rows = []
    for size in sizes:
        for seed in range(seeds):
            before = perf_counter_ns()
            world = grid_world(size, seed)
            map_build_ms = (perf_counter_ns() - before) / 1_000_000
            blocked = frozenset()
            check_areas(world, blocked)
            optimum = bfs_distances(world.adj, world.start, blocked)[world.goal]
            assert optimum == world.optimum
            hierarchy = prepare_hierarchy(world, blocked)
            algorithms = {
                "Flat A*": lambda: flat_astar(world, world.start, world.goal, blocked,
                                             heuristic=world.heuristic(world.goal)),
                "Two-tier A*": lambda: two_tier_search(world, world.start, world.goal, blocked,
                                                       hierarchy=hierarchy),
            }
            def run_checked(method):
                result = algorithms[method]()
                assert result.found and result.path[0] == world.start and result.path[-1] == world.goal
                assert abs(route_cost(world, result.path, blocked) - result.cost_m) < 1e-7
                assert result.cost_m >= optimum
                if method == "Flat A*":
                    assert result.cost_m == optimum
                return result

            for method in algorithms:
                run_checked(method)
            for repeat in range(repeats):
                order = list(algorithms)
                if repeat % 2:
                    order.reverse()
                for method in order:
                    result = run_checked(method)
                    abstract = getattr(result, "abstract_expanded", 0)
                    rows.append({
                        "size": size, "seed": seed, "repeat": repeat, "method": method,
                        "runtime_ms": result.runtime_ms,
                        "detailed_nodes": result.nodes_expanded, "abstract_nodes": abstract,
                        "total_nodes": result.nodes_expanded + abstract,
                        "cost": result.cost_m,
                        "map_build_ms": map_build_ms,
                        "preprocessing_ms": hierarchy.preprocess_ms if method == "Two-tier A*" else 0,
                        "area_count": len(hierarchy.adj),
                    })
    summary = []
    for size in sizes:
        for method in ("Flat A*", "Two-tier A*"):
            group = [r for r in rows if r["size"] == size and r["method"] == method]
            record = {"size": size, "method": method}
            for metric in ("runtime_ms", "detailed_nodes", "abstract_nodes", "total_nodes",
                           "cost", "map_build_ms", "preprocessing_ms"):
                seed_means = [
                    statistics.mean(r[metric] for r in group if r["seed"] == seed)
                    for seed in range(seeds)
                ]
                record[metric + "_mean"] = statistics.mean(seed_means)
                record[metric + "_sd"] = statistics.stdev(seed_means) if seeds > 1 else 0.0
            summary.append(record)
    metadata = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "python": platform.python_version(), "platform": platform.platform(),
        "sizes": list(sizes), "seeds": list(range(seeds)), "repeats": repeats,
        "warmups_per_method_per_map": 1,
        "shared_source_commit": "a46acbf21abbfebb04ff725428d9b5c7d0141d87",
        "trial_count": len(rows), "region_rule": "8x8 tiles split into connected components",
        "timing": (
            "Query time excludes map construction and hierarchy preprocessing. "
            "Map construction includes grid generation and connected area partitioning "
            "and is shared by both methods. The two-tier hierarchy is built once per map."
        ),
        "variability": "Sample standard deviation across per-map means.",
        "validation": "Every route checked; flat costs match independent BFS distances.",
    }
    if output:
        output = Path(output)
        output.mkdir(parents=True, exist_ok=True)
        write_csv(output / "trials.csv", rows)
        write_csv(output / "summary.csv", summary)
        (output / "metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    return {"summary": summary, "metadata": metadata}


if __name__ == "__main__":
    data = run_benchmark(ROOT / "results" / "integrated")
    print(json.dumps(data, indent=2))
