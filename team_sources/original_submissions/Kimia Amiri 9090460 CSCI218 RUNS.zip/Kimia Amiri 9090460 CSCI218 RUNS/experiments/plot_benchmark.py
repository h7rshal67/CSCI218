"""Plot the integrated benchmark summary. Requires matplotlib."""
import csv
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

RESULTS = Path(__file__).resolve().parents[1] / "results" / "integrated"


def main():
    with (RESULTS / "summary.csv").open(newline="", encoding="utf-8") as stream:
        summary = list(csv.DictReader(stream))

    methods = [("Flat A*", "#215981", "o", -0.055), ("Two-tier A*", "#ad4c25", "s", 0.055)]
    metrics = [("detailed_nodes", "Detailed expansions"), ("runtime_ms", "Query time (ms)"),
               ("cost", "Route length (moves)")]
    sizes = sorted({int(row["size"]) for row in summary})
    fig, axes = plt.subplots(1, 3, figsize=(10.6, 3.5))
    for ax, (metric, title) in zip(axes, metrics):
        for method, color, marker, offset in methods:
            rows = sorted((row for row in summary if row["method"] == method),
                          key=lambda row: int(row["size"]))
            ax.errorbar([sizes.index(int(row["size"])) + offset for row in rows],
                        [float(row[metric + "_mean"]) for row in rows],
                        yerr=[float(row[metric + "_sd"]) for row in rows],
                        color=color, marker=marker, capsize=3, linewidth=1.6)
        ax.set(title=title, xticks=range(len(sizes)),
               xticklabels=[f"{size} × {size}" for size in sizes])
        ax.grid(axis="y", alpha=0.23)
        ax.spines[["top", "right"]].set_visible(False)
    handles = [Line2D([0], [0], color=color, marker=marker, label=method)
               for method, color, marker, _ in methods]
    fig.legend(handles=handles, loc="upper center", ncol=2, frameon=False)
    fig.subplots_adjust(top=0.81, bottom=0.14, left=0.08, right=0.98, wspace=0.33)
    fig.savefig(RESULTS / "grid_benchmark.png", dpi=250)
    plt.close(fig)


if __name__ == "__main__":
    main()
