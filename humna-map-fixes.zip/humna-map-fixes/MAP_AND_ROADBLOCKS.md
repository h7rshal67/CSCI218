# Map, hubs and roadblock scenarios

Component: map, areas and disruption scenarios (`osm_map.py`, `first_level_search.py`).
Owner: Humna. Fixes and tests in this document were prepared with assistance from Claude
(an AI assistant); Humna checked and ran them.

## Map data

| Item | Value |
| --- | --- |
| Source | OpenStreetMap, (c) OpenStreetMap contributors, ODbL: https://www.openstreetmap.org/copyright |
| Downloaded with | Humna's `download_osm.py` script (Overpass API), box below |
| Data snapshot time | 2026-07-24T11:04:51Z (`osm_base` in the file header) |
| Downloaded on | 12 November 2026 (Humna's run; file size 4,457,649 bytes) |
| Usable road points | 23,400 (largest strongly connected part of the drivable roads) |

Download box: south 25.185, west 55.225, north 25.245, east 55.275.

Roads kept: motorway, trunk, primary, secondary, tertiary (and their links), residential,
unclassified, living street, service. Footways, paths and crossings are ignored. One-way roads
and roundabouts are one-way edges, so closures and routes are directed.

## Hubs and areas

Each hub is a named place in the OSM file, snapped to its nearest road point. Every road point
then belongs to the hub it is closest to **by road distance**, so each area is one connected piece.

| Hub | OSM name used | Metres from place to road |
| --- | --- | --- |
| Boxpark | Boxpark | 17 |
| Art House | Art House Dubai | 37 |
| Fishing Harbour | Jumeirah Fishing Harbour | 6 |
| Carrefour Market | Carrefour Market | 18 |
| Mercato Mall | pinned at 25.2163, 55.2533 | 66 |
| Jumeirah Beach Centre | Jumeriah Beach Cental Center (spelled as in OSM) | 36 |
| La Mer | La Mer | 137 |
| Port de La Mer | Port de La Mer | 154 |

"Mercato Shopping Mall" appears three times in the file, two at 25.2156, 55.2510 and one at
25.2163, 55.2533, so the hub is pinned to the second place. The loader now keeps the first
place for any repeated name and warns if a hub relies on a repeated name.

## Hub-level search

The hub map joins two hubs when their areas touch. The cost of a join is the real road distance
between the two hubs' road points (closed roads are skipped). A* then finds the cheapest chain of
hubs. The guess score is the straight-line distance between the two hubs' **road points**, which
never overestimates the road distance, so the result matches a plain search without the guess.

## Roadblock scenarios (reproducible)

A roadblock closes every road edge, in both directions, with an end point within a radius of the
middle road point of the middle leg of the route found without any roadblock. It is deterministic.

| Scenario | Radius | Road edges closed | Route | Length |
| --- | --- | --- | --- | --- |
| No roadblock | - | 0 | Boxpark, Carrefour Market, La Mer, Port de La Mer | 7,213 m |
| Small roadblock | 60 m | 25 | same hubs, detour | 7,239 m |
| Large roadblock | 150 m | 181 | same hubs, detour | 7,346 m |

The 60 m case is the demo's "hub" closure scenario (`worlds.closures_for`). Both cases are
rebuilt and checked by `tests/test_map_fixes.py`.

## Known limitations

- The hub route is not the shortest road route. The full-map flat A* shortest route from Boxpark
  to Port de La Mer is 6,551.7 m, so the hub route (7,213 m) is about 10% longer, because it has
  to pass through the hubs' road points.
- A leg between two touching hubs is the shortest road route between them and can pass through
  a third area.
- La Mer and Port de La Mer are 137 m and 154 m from the nearest road, so their hub road points
  are only approximate positions of the places.
- A roadblock close to a hub can cut that hub off completely (150 m around the La Mer hub closes 186
  edges and the hub search finds no route from Boxpark to Port de La Mer).
